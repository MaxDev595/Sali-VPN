import { Alert, Linking, Pressable, SafeAreaView, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { theme } from '../../src/theme';

type Settings = { auto: boolean; wifi: boolean; kill: boolean; notifications: boolean };
const defaults: Settings = { auto: false, wifi: true, kill: true, notifications: true };
const storageKey = 'sali.settings';

function Row({ title, value, toggle, onChange, onPress }: { title: string; value?: string; toggle?: boolean; onChange?(value: boolean): void; onPress?(): void }) {
  const content = <><Text style={styles.rowTitle}>{title}</Text>{onChange ? <Switch value={toggle} onValueChange={onChange} trackColor={{ false: theme.colors.muted, true: theme.colors.brand }} thumbColor={toggle ? theme.colors.accent : '#D9DEE6'} /> : <Text style={styles.value}>{value}{onPress ? '  ›' : ''}</Text>}</>;
  return onPress ? <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>{content}</Pressable> : <View style={styles.row}>{content}</View>;
}

export default function SettingsScreen() {
  const [settings, setSettings] = useState(defaults);
  useEffect(() => { void AsyncStorage.getItem(storageKey).then(value => { if (value) setSettings({ ...defaults, ...JSON.parse(value) as Partial<Settings> }); }).catch(() => {}); }, []);
  const update = (key: keyof Settings, value: boolean) => { const next = { ...settings, [key]: value }; setSettings(next); void AsyncStorage.setItem(storageKey, JSON.stringify(next)); };
  const open = async (url: string) => { if (await Linking.canOpenURL(url)) await Linking.openURL(url); else Alert.alert('Не удалось открыть ссылку'); };
  const info = (title: string, message: string) => Alert.alert(title, message);
  return <SafeAreaView style={styles.safe}><ScrollView contentContainerStyle={styles.screen}><Text style={styles.title}>Настройки</Text><Text style={styles.section}>VPN</Text><View style={styles.card}><Row title="Автоподключение" toggle={settings.auto} onChange={value => update('auto', value)} /><Row title="Защита публичного Wi‑Fi" toggle={settings.wifi} onChange={value => update('wifi', value)} /><Row title="Kill Switch" toggle={settings.kill} onChange={value => update('kill', value)} /><Row title="Протокол" value="WireGuard" onPress={() => info('Протокол', 'Sali использует быстрый и безопасный протокол WireGuard.')} /><Row title="DNS" value="Sali DNS" onPress={() => info('DNS', 'DNS-запросы отправляются через защищённое VPN-соединение.')} /></View><Text style={styles.section}>ПРИЛОЖЕНИЕ</Text><View style={styles.card}><Row title="Язык" value="Русский" onPress={() => info('Язык', 'Сейчас доступен русский язык.')} /><Row title="Уведомления" toggle={settings.notifications} onChange={value => update('notifications', value)} /></View><Text style={styles.section}>ПОДДЕРЖКА</Text><View style={styles.card}><Row title="Помощь и поддержка" value="Telegram" onPress={() => void open('https://t.me/SaliSupportBot')} /><Row title="Политика конфиденциальности" value="" onPress={() => info('Политика конфиденциальности', 'Документ будет опубликован перед публичным релизом.')} /><Row title="Условия использования" value="" onPress={() => info('Условия использования', 'Документ будет опубликован перед публичным релизом.')} /><Row title="О Sali" value="0.1.3" onPress={() => info('Sali VPN 0.1.3', 'Приватное подключение в одно нажатие.')} /></View></ScrollView></SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: theme.colors.background }, screen: { padding: 20, paddingBottom: 44 }, title: { color: theme.colors.textPrimary, fontSize: 34, fontWeight: '800', marginTop: 18, marginBottom: 22 }, section: { color: theme.colors.textSecondary, fontSize: 12, fontWeight: '800', letterSpacing: 1.3, marginTop: 20, marginBottom: 9, marginLeft: 4 }, card: { borderRadius: 20, backgroundColor: theme.colors.surface, borderWidth: 1, borderColor: theme.colors.border, overflow: 'hidden' }, row: { minHeight: 64, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: theme.colors.border }, rowPressed: { backgroundColor: theme.colors.surfaceElevated }, rowTitle: { color: theme.colors.textPrimary, fontSize: 17, lineHeight: 22, fontWeight: '600', flex: 1 }, value: { color: theme.colors.textSecondary, fontSize: 15 } });
