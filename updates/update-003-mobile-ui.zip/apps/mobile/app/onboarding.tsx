import { useEffect, useRef, useState } from 'react';
import { Dimensions, FlatList, Pressable, SafeAreaView, StyleSheet, Text, View, ViewToken } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import { useVideoPlayer, VideoView } from 'expo-video';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { BrandMark } from '../src/components/BrandMark';
import { SaliButton } from '../src/components/SaliButton';
import { theme } from '../src/theme';

const width = Dimensions.get('window').width;
const pages = [
  { number: '01', title: 'Приватность без сложности', text: 'Sali защищает весь трафик устройства. Никаких ручных настроек — всё готово к работе.' },
  { number: '02', title: 'Подключение в одно нажатие', text: 'Выберите подходящий сервер и нажмите большую кнопку. Остальное приложение сделает само.' },
  { number: '03', title: 'Свобода каждый день', text: 'Быстрый, спокойный и приватный интернет дома, в дороге и в общественных сетях.' },
];

export default function OnboardingScreen() {
  const [showIntro, setShowIntro] = useState(true);
  const [page, setPage] = useState(0);
  const list = useRef<FlatList<(typeof pages)[number]>>(null);
  const player = useVideoPlayer(require('../assets/sali-logo-motion.webm'), value => { value.loop = false; value.muted = true; value.play(); });
  useEffect(() => { const timer = setTimeout(() => setShowIntro(false), 2600); return () => clearTimeout(timer); }, []);
  const finish = async () => { await AsyncStorage.setItem('sali.onboarding.v2.complete', '1'); router.replace('/'); };
  const next = () => page === pages.length - 1 ? void finish() : list.current?.scrollToIndex({ index: page + 1 });
  const viewability = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => setPage(viewableItems[0]?.index ?? 0)).current;

  if (showIntro) return <Animated.View entering={FadeIn.duration(220)} exiting={FadeOut.duration(320)} style={styles.intro}><VideoView player={player} style={styles.introVideo} nativeControls={false} contentFit="contain" /><Pressable accessibilityRole="button" accessibilityLabel="Пропустить заставку" onPress={() => setShowIntro(false)} style={styles.skipIntro}><Text style={styles.skipText}>Пропустить</Text></Pressable></Animated.View>;

  return <SafeAreaView style={styles.safe}><View style={styles.header}><BrandMark size={48} /><Text style={styles.brandName}>Sali VPN</Text><Pressable onPress={() => void finish()}><Text style={styles.skip}>Пропустить</Text></Pressable></View><FlatList ref={list} data={pages} horizontal pagingEnabled showsHorizontalScrollIndicator={false} onViewableItemsChanged={viewability} viewabilityConfig={{ itemVisiblePercentThreshold: 60 }} keyExtractor={item => item.number} renderItem={({ item }) => <View style={styles.page}><View style={styles.numberCircle}><Text style={styles.number}>{item.number}</Text></View><Text style={styles.title}>{item.title}</Text><Text style={styles.text}>{item.text}</Text></View>} /><View style={styles.footer}><View style={styles.dots}>{pages.map((_, index) => <View key={index} style={[styles.dot, index === page && styles.dotActive]} />)}</View><SaliButton title={page === pages.length - 1 ? 'Начать пользоваться' : 'Продолжить'} onPress={next} /></View></SafeAreaView>;
}

const styles = StyleSheet.create({ intro: { flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' }, introVideo: { width: '100%', height: '100%' }, skipIntro: { position: 'absolute', right: 22, top: 52, paddingHorizontal: 14, paddingVertical: 10 }, skipText: { color: '#C7CED8', fontSize: 15, fontWeight: '600' }, safe: { flex: 1, backgroundColor: theme.colors.background }, header: { height: 78, paddingHorizontal: 22, flexDirection: 'row', alignItems: 'center', gap: 12 }, brandName: { color: theme.colors.textPrimary, fontSize: 20, fontWeight: '700', flex: 1 }, skip: { color: theme.colors.textSecondary, fontSize: 15, fontWeight: '600' }, page: { width, paddingHorizontal: 28, alignItems: 'center', justifyContent: 'center', paddingBottom: 20 }, numberCircle: { width: 132, height: 132, borderRadius: 66, borderWidth: 1, borderColor: theme.colors.border, backgroundColor: theme.colors.surface, alignItems: 'center', justifyContent: 'center', marginBottom: 38 }, number: { color: theme.colors.accent, fontSize: 34, fontWeight: '800' }, title: { color: theme.colors.textPrimary, fontSize: 32, lineHeight: 38, fontWeight: '800', textAlign: 'center' }, text: { color: theme.colors.textSecondary, fontSize: 18, lineHeight: 27, textAlign: 'center', marginTop: 16, maxWidth: 340 }, footer: { paddingHorizontal: 24, paddingBottom: 22, gap: 24 }, dots: { flexDirection: 'row', gap: 8, alignSelf: 'center' }, dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: theme.colors.muted }, dotActive: { width: 26, backgroundColor: theme.colors.accent } });
